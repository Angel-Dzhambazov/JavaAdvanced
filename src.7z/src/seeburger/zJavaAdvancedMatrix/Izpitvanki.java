package zJavaAdvancedMatrix;

public class Izpitvanki {
	public static void main(String[] args) {
		int n = 5;
		System.out.println("tuka shte printira ebasi");
		for (int i = 0; i < args.length; i++) {
			for (int j = 0; j < args.length; j++) {
				System.out.println("ebasi");
			}
		}
	}
}
