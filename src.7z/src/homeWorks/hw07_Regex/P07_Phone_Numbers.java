
package homeWorks.hw07_Regex;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class P07_Phone_Numbers {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));






    }
}
