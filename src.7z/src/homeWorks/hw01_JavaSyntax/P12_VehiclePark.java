package homeWorks.hw01_JavaSyntax;

/**
 * Created by fluch on 4/22/2017.
 */
public class P12_VehiclePark {
}
