package homeWorks.hw05_Files_and_Streams;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by fluch on 6/8/2018.
 */
public class Test {
    public static void main(String[] args) {
        List<String> test = new ArrayList<>();
        test.add("gogo");
        test.add("gogo");
        test.add("gogo");
        test.add("gogo");
        test.add("gogo");
        System.out.println(test.size());
    }
}
